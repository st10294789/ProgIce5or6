﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Oracle.EntityFrameworkCore;

namespace ProgIce5or6
{

    public class UserInfo
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [Column("FirstName")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Surname is required")]
        [Column("Surname")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Birth Year is required")]
        [Column("YearOfBirth")]
        public int YearOfBirth { get; set; }
    }
}