﻿using Microsoft.EntityFrameworkCore;
using Oracle.EntityFrameworkCore;
using ProgIce5or6.Models;

namespace ProgIce5or6.data
{

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> madeupOptions)
            : base(madeupOptions)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.HasDefaultSchema("SYS");  // Use the schema from your connection string

            // Configure identity columns for all entities
            foreach (var entity in modelBuilder.Model.GetEntityTypes())
            {
                var properties = entity.GetProperties().Where(p => p.ClrType == typeof(int) && p.Name == "Id");
                foreach (var property in properties)
                {
                    property.ValueGenerated = Microsoft.EntityFrameworkCore.Metadata.ValueGenerated.OnAdd;
                }
            }
        }

        public DbSet<UserInfo> Users { get; set; }
    }
}